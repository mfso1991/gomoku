#ifndef _types_h_
#define _types_h_

#include <vector>

// state of the game is rememebred in this
typedef std::vector< std::vector< char > > TBoard;

#endif
